package brickwall;

import java.util.Scanner;

public class wallpro {

	static int Layer1[][];				// First Layer of the wall
	static int Layer2 [][];				// Second Layer of the wall
	static int N;						// number of rows in a Layer
	static int M;						// number of bricks in a row
	static int wrong = 0;				// variable for checking if the First Layer is built according to the instructions
	static int style = 0;				// this variable determines which building model must be used for the Second Layer
	static String [][] due;				// we use this massive in order to put lines between the bricks of the Second Layer
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scan = new Scanner(System.in);								// we create a scanner in order to input values
		
		System.out.println("Input proper Number of Lines: ");				// written message
		N = scan.nextInt();													// type the number of rows in a Layer
		
		while ((N<1)||(N%2!=0)||(N>100)) {									// you will type until the conditions for the number of rows are met 
			System.out.println("Error: Input proper Number of Lines: ");	// written message
			N = scan.nextInt();							
		}
		
		System.out.println("Input proper Number of Bricks: ");				// written message
		M = scan.nextInt();													// type the number of bricks in a row
		
		while ((M<4)||(M%4!=0)||(M>100)) {									// you will type until the conditions for the number of bricks are met
			System.out.println("Error: Input proper Number of Bricks: ");	// written message
			M = scan.nextInt();
		}		

		System.out.println("Input numbers to build the first Layer :");		// written message
		Layer1 = new int [N][M];											// the First Layer will have N rows and M bricks per row
		
		for (int i=0; i<N; i++) {							// going through all the rows one by one
			for (int j=0; j<M; j++) {						// going through the all the bricks in a row
				Layer1 [i][j] = scan.nextInt(); 			// input all the brick numbers that form the First Layer
			}												// divide the bricks via space and press enter for next row 
		}
		due = new String [N][M];							// setting up the Second Layer that will have lines between the bricks

		System.out.println();
				
		Test();								// testing if the bricks are properly numbered
		if (wrong==0) {						// if the test with the bricks was positive - we proceed  
			Test1();						// checking if the First Layer is build according to the first method   
			if (wrong == 1) {				// if the first method was false - we go to the next one 
				Test2();					// checking if the First Layer is build according to the second method  
				if (wrong == 1) {			// if the second method was false - we go to the next one  
					Test3();				// checking if the First Layer is build according to the third method  
					if (wrong == 1) {		// if the third method was false - we go to the next one  	
						Test4();			// checking if the First Layer is build according to the fourth method  
						if (wrong == 1) {		// if the third method was false - we go to the next one  	
							Test5();			// checking if the First Layer is build according to the fourth method  
							if (wrong == 1) {		// if the third method was false - we go to the next one  	
								Test6();			// checking if the First Layer is build according to the fourth method  
							}
						}
					}
				}
			}		
		} 
				
		if (wrong==1) {												// the First Layer was not build according to the instructions 
			System.out.println("Error: There is no solution");		// the Second Layer can not be completed
		} else {
			
			System.out.println("Here is how the second layer must be built:");  	// written message
			
			Layer2 = new int [N][M];			// the Second Layer will have N rows and M bricks per row
			
			switch (style) {					// checking which building model must be used for the Second Layer 
			
				case 1: MakeWall1(); break;		// use the first building model for the Second Layer
				case 2: MakeWall2(); break;		// use the second building model for the Second Layer
				case 3: MakeWall3(); break;		// use the third building model for the Second Layer
				case 4: MakeWall3(); break;		// use a variation of the third building model for the Second Layer
			}
		}		
	}

	public static void Test() {					// testing if the bricks are numbered with numbers from 1 to M
		
		for (int j=0; j<M; j++) {				// going through the numbers from 1 to M
			
			int check = j+1;					// the variable will take the value of each of the numbers from 1 to M
			int match = 0;						// the times a single number repeats
			
			for (int k=0; k<N; k++) {							// going through the all the rows
				
				for (int f=0; f<M; f++) {						// going through the all the bricks in a row
																// we will compare each brick's number to the ones from 1 to M
					if (check==Layer1[k][f]) {match++;}			// if there is a match, the counter will grow			
				} 
			}	if (match!=2) {wrong=1; break;} 				// a single number must not repeat more than twice 
		}														// otherwise the instructions were not met
	}	
	
	public static void Test1() {			// checking if the First Layer is build according to the first method   
		
		style = 1;							// the model that will be used if this method was applied to the First Layer
		
		for (int i=0; i<N; i++) {			// we examine all the bricks in the First Layer by row
			for (int j=0; j<M; j++) {
				
				if (((i+1)%2==0)&&((j+1)%4==0)) {						// we inspect from the even rows upwards and every fourth brick backwards
										
					if 	((Layer1 [i][j-3] == Layer1 [i-1][j-3])&&		//  the numbers on the vertical brick on the left must be the same
						(Layer1 [i-1][j-2] == Layer1 [i-1][j-1])&&		//  the numbers on the upper brick in the middle must be the same
						(Layer1 [i][j-2] == Layer1 [i][j-1])&&			//  the numbers on the lower brick in the middle must be the same
						(Layer1 [i][j] == Layer1 [i-1][j]))				//  the numbers on the vertical brick on the right must be the same
	
						{wrong = 0;} else {wrong=1;}					// if all the numbers don't match, then the method is false
					
				} if (wrong==1) {break;}								// if there is a flaw, we stop the inspection
			} 
		}	
	}
	
	public static void Test2() {				// checking if the First Layer is build according to the second method   
		
		style = 2;								// the model that will be used if this method was applied to the First Layer
		
			wrong = 0;							// we erase the false report from the previous method in order to try out the current
			for (int i=0; i<N; i++) {			// we examine all the bricks in the First Layer by row
				int same = 0;					// this variable will inspect if the numbers of each brick match in pairs 
				for (int j=0; j<M; j++) {
					
					if ((j+1)%2!=0) {				// we check the first half of the brick
						same = Layer1 [i][j];		// the variable takes the value of the first half of the brick
					}							
					else {
										
						if(same!=Layer1 [i][j]) { 	// the variable is compared to the second half of the brick
							wrong = 1;				// if they don't match, then the method is false
						}
					} if (wrong==1) {break;}		// if there is a flaw, we stop the inspection
				} 	
			}			
		}
		
	public static void Test3() {			// checking if the First Layer is build according to the third method   
		
		style = 3;							// the model that will be used if this method was applied to the First Layer

		wrong = 0;							// we erase the false report from the previous method in order to try out the current
		int Que = 0;						// this variable will count the bricks from 1 to 8 along the row
		for (int i=0; i<N; i++) {			// we examine all the bricks in the First Layer by row

			int same = 0;						// this variable will inspect if the numbers of each brick match in pairs 
			
			for (int j=0; j<M; j++) {							
				Que++;							// the counter grows with each brick number
				
				if (((i+1)%2==0)&&((j+1)%4==0)&&(Que<=4)) {			// we inspect from the even rows upwards and every fourth brick backwards while the counter is below 5
					
					if 	((Layer1 [i][j-3] == Layer1 [i-1][j-3])&&		//  the numbers on the vertical brick on the left must be the same
						(Layer1 [i-1][j-2] == Layer1 [i-1][j-1])&&		//  the numbers on the upper brick in the middle must be the same
						(Layer1 [i][j-2] == Layer1 [i][j-1])&&			//  the numbers on the lower brick in the middle must be the same
						(Layer1 [i][j] == Layer1 [i-1][j]))				//  the numbers on the vertical brick on the right must be the same
		
						{wrong = 0;} else {wrong=1;}					// if all the numbers don't match, then the method is false
				}
				
				if (Que>4) {										// we inspect the rows while the counter is between 4 and 9
					if (Que%2!=0) {									// if the counter is even
						same = Layer1 [i][j];						// the variable takes the value of the first half of the brick
					}												
											
					if((Que%2==0)&&(same!=Layer1 [i][j])) {			// the variable is compared to the second half of the brick
						wrong = 1;									// if they don't match, then the method is false
					}
										
				} if (wrong==1) {break;} 		// if there is a flaw, we stop the inspection
					if (Que>=8) {Que=0;}		// if the counter equals or is above 8 we nullify it 
			} 		
		}		
	}
	
	public static void Test4() {			// checking if the First Layer is build according to the fourth method 
		
		style = 4;							// the model that will be used if this method was applied to the First Layer			

		wrong = 0;							// we erase the false report from the previous method in order to try out the current
		int Que = 0;						// this variable will count the bricks from 1 to 8 along the row
		for (int i=0; i<N; i++) {			

			int same = 0;					// this variable will inspect if the numbers of each brick match in pairs 
			
			for (int j=0; j<M; j++) {								
				Que++;						// the counter grows with each brick number
				
				if (((i+1)%2==0)&&((j+1)%4==0)&&(Que>4)) {				// we inspect from the even rows upwards and every fourth brick backwards while the counter is above 4
					
					if 	((Layer1 [i][j-3] == Layer1 [i-1][j-3])&&		//  the numbers on the vertical brick on the left must be the same
						(Layer1 [i-1][j-2] == Layer1 [i-1][j-1])&&		//  the numbers on the upper brick in the middle must be the same
						(Layer1 [i][j-2] == Layer1 [i][j-1])&&			//  the numbers on the lower brick in the middle must be the same
						(Layer1 [i][j] == Layer1 [i-1][j]))				//  the numbers on the vertical brick on the right must be the same
						
						{wrong = 0;} else {wrong=1;}					// if all the numbers don't match, then the method is false
				}
				
				if (Que<=4) {										// we inspect the rows while the counter is below 5
					if (Que%2!=0) {									// if the counter is even
						same = Layer1 [i][j];						// the variable takes the value of the first half of the brick
					}												
											
					if((Que%2==0)&&(same!=Layer1 [i][j])) {			// the variable is compared to the second half of the brick
						wrong = 1;									// if they don't match, then the method is false
					}
										
				} if (wrong==1) {break;} 		// if there is a flaw, we stop the inspection
					if (Que>=8) {Que=0;}		// if the counter equals or is above 8 we nullify it 
			} 		
		}		
	}	
	
	public static void Test5() {			// checking if the First Layer is build according to the fifth method 
		
		style = 3;							// the model that will be used if this method was applied to the First Layer			

		wrong = 0;							// we erase the false report from the previous method in order to try out the current
		int Que = 0;						// this variable will count the bricks from 1 to 8 along the row
		for (int i=0; i<N; i++) {			

			int same = 0;					// this variable will inspect if the numbers of each brick match in pairs 
			
			for (int j=0; j<M; j++) {								
				Que++;						// the counter grows with each brick number
				
				if (((i+1)%2==0)&&((i+1)%4!=0)&&((j+1)%4==0)) {			// we inspect from every second row upwards and every fourth brick backwards
					
					if 	((Layer1 [i][j-3] == Layer1 [i-1][j-3])&&		//  the numbers on the vertical brick on the left must be the same
						(Layer1 [i-1][j-2] == Layer1 [i-1][j-1])&&		//  the numbers on the upper brick in the middle must be the same
						(Layer1 [i][j-2] == Layer1 [i][j-1])&&			//  the numbers on the lower brick in the middle must be the same
						(Layer1 [i][j] == Layer1 [i-1][j]))				//  the numbers on the vertical brick on the right must be the same
						
						{wrong = 0;} else {wrong=1;}					// if all the numbers don't match, then the method is false
				}
				
				if (((i+1)%4==0)&&((j+1)%4==0)) {							// we inspect from every fourth row upwards and every fourth brick backwards
					if 	((Layer1 [i-1][j-1] == Layer1 [i-1][j])&&			//  the numbers on the upper brick on the right must be the same
							(Layer1 [i-1][j-2] == Layer1 [i-1][j-3])&&		//  the numbers on the upper brick on the left must be the same
							(Layer1 [i][j-2] == Layer1 [i][j-3])&&			//  the numbers on the lower brick on the left must be the same
							(Layer1 [i][j-1] == Layer1 [i][j]))				//  the numbers on the lower brick on the right must be the same
			
							{wrong = 0;} else {wrong=1;}
										
				} if (wrong==1) {break;} 		// if there is a flaw, we stop the inspection
					if (Que>=8) {Que=0;}		// if the counter equals or is above 8 we nullify it 
			} 		
		}		
	}
	
	public static void Test6() {			// checking if the First Layer is build according to the sixth method   
		
		style = 4;							// the model that will be used if this method was applied to the First Layer

		wrong = 0;							// we erase the false report from the previous method in order to try out the current
		int Que = 0;						// this variable will count the bricks from 1 to 8 along the row
		for (int i=0; i<N; i++) {			// we examine all the bricks in the First Layer by row

			int same = 0;						// this variable will inspect if the numbers of each brick match in pairs 
			
			for (int j=0; j<M; j++) {							
				Que++;							// the counter grows with each brick number
				
				if (((i+1)%4==0)&&((j+1)%4==0)) {						// we inspect from every fourth row upwards and every fourth brick backwards
					
					if 	((Layer1 [i][j-3] == Layer1 [i-1][j-3])&&		//  the numbers on the vertical brick on the left must be the same
						(Layer1 [i-1][j-2] == Layer1 [i-1][j-1])&&		//  the numbers on the upper brick in the middle must be the same
						(Layer1 [i][j-2] == Layer1 [i][j-1])&&			//  the numbers on the lower brick in the middle must be the same
						(Layer1 [i][j] == Layer1 [i-1][j]))				//  the numbers on the vertical brick on the right must be the same
		
						{wrong = 0;} else {wrong=1;}					// if all the numbers don't match, then the method is false
				}
				
				if (((i+1)%2==0)&&((i+1)%4!=0)&&((j+1)%4==0)) {				// we inspect from every second row upwards and every fourth brick backwards

					if 	((Layer1 [i-1][j-1] == Layer1 [i-1][j])&&			//  the numbers on the upper brick on the right must be the same
							(Layer1 [i-1][j-2] == Layer1 [i-1][j-3])&&		//  the numbers on the upper brick on the left must be the same
							(Layer1 [i][j-2] == Layer1 [i][j-3])&&			//  the numbers on the lower brick on the left must be the same
							(Layer1 [i][j-1] == Layer1 [i][j]))				//  the numbers on the lower brick on the right must be the same
			
							{wrong = 0;} else {wrong=1;}
										
				} if (wrong==1) {break;} 		// if there is a flaw, we stop the inspection
					if (Que>=8) {Que=0;}		// if the counter equals or is above 8 we nullify it 
			} 		
		}		
	}
	
	public static void MakeWall1() {			// making a Second Layer according to model 1

		int x = 1;								// the variable will give the bricks numbers
		for (int i=0; i<N; i++) {				// going through all the rows
						
			for (int j=0; j<M; j++) {			// going through all the bricks on the row
			
				Layer2[i][j] = x;				// the current brick is given a number
				
				if 	((j+1)%2==0) {x++; System.out.print(Layer2 [i][j]+" - ");} 		// with every next brick the number grows, we put lines in between the bricks								
				else {System.out.print(Layer2 [i][j]+" ");}							// no lines between, the number remains the same 
			}	System.out.println();												// going to the next row
		}
	}
	
	public static void MakeWall2() {		// making a Second Layer according to model 2

		int G = 0;							// this variable will count the bricks from 0 to 3 along the row 
		int x = 1;							// the variable will give the bricks numbers
		for (int i=0; i<N; i++) {			// going through all the rows
						
			for (int j=0; j<M; j++) {		// going through all the bricks in a row
			
				if 	((i+1)%2==0) {			// we build from the even rows upwards
					
					switch (G) {			// each build up that follows depends on the number of the counter
					
						case 0: Layer2[i][j] = Layer2[i-1][j] = x+1; x++; 																		//  if the counter is 0 - the numbers on the vertical brick on the left are made the same
						due [i][j] = Integer.toString(Layer2 [i][j])+" -"; due [i-1][j] = Integer.toString(Layer2 [i-1][j])+" -"; break;		//  turning the numbers to strings in order to put lines in between 
						case 1: Layer2[i-1][j] = Layer2[i-1][j+1] = x-1; x++; 																	//  if the counter is 1 - the numbers on the upper brick in the middle are made the same
						due[i-1][j]  = Integer.toString(Layer2[i-1][j] )+""; due[i-1][j+1] = Integer.toString(Layer2[i-1][j+1] )+" -"; break;	//  turning the numbers to strings in order to put lines in between 
						case 2: Layer2[i][j] = Layer2[i][j-1] = x; x++; 																		//  if the counter is 2 - the numbers on the lower brick in the middle are made the same
						due[i][j]  = Integer.toString(Layer2[i][j] )+" -"; due[i][j-1] = Integer.toString(Layer2[i][j-1] )+""; break;			//  turning the numbers to strings in order to put lines in between 
						case 3: Layer2[i][j] = Layer2[i-1][j] = x; x++; 																		//  if the counter is 3 - the numbers on the vertical brick on the right are made the same
						due[i][j] = Integer.toString(Layer2[i][j] )+" -"; due[i-1][j] = Integer.toString(Layer2[i-1][j] )+" -"; break;			//  turning the numbers to strings in order to put lines in between 
					}								
					 G++;				// the number of the counter grows
					 if(G>3) {G=0;}		// if the counter equals is above 3 we nullify it  		
				}						
			}			
		}
		for (int i=0; i<N; i++) {					// going through all the rows
			
			for (int j=0; j<M; j++) {				// going through all the bricks in a row
				System.out.print(due [i][j]+" ");	// laying out the bricks 			
			}
			System.out.println();					// going to the next row
		}
	}
	
	public static void MakeWall3() {			// making a Second Layer according to model 3
		
		int G = 4;								// this variable will count the bricks from 0 to 7 along the row, we use it this value if Test3 is approved		
		if (style > 3) {G = 0;}					// we reset the variable in case Test3 fails but Test4 is approved
		int x = 1;								// the variable will give the bricks numbers
		for (int i=0; i<N; i++) {				// going through all the rows
						
			for (int j=0; j<M; j++) {			// going through all the bricks in a row
//			
				if 	((i+1)%2==0) {				// we build from the even rows upwards
					
					switch (G) {				// each build up that follows depends on the number of the counter
					
					case 0: Layer2[i][j] = Layer2[i-1][j] = x+1; x++; 																		//  if the counter is 0 - the numbers on the vertical brick on the left are made the same
					due [i][j] = Integer.toString(Layer2 [i][j])+" -"; due [i-1][j] = Integer.toString(Layer2 [i-1][j])+" -";break;			//  turning the numbers to strings in order to put lines in between 
					case 1: Layer2[i-1][j] = Layer2[i-1][j+1] = x-1; x++; 																	//  if the counter is 1 - the numbers on the upper brick in the middle are made the same
					due[i-1][j]  = Integer.toString(Layer2[i-1][j] )+""; due[i-1][j+1] = Integer.toString(Layer2[i-1][j+1] )+" -"; break;	//  turning the numbers to strings in order to put lines in between 
					case 2: Layer2[i][j] = Layer2[i][j-1] = x; x++; 																		//  if the counter is 2 - the numbers on lower brick in the middle are made the same
					due[i][j]  = Integer.toString(Layer2[i][j] )+" -"; due[i][j-1] = Integer.toString(Layer2[i][j-1] )+""; break;			//  turning the numbers to strings in order to put lines in between 
					case 3: Layer2[i][j] = Layer2[i-1][j] = x; x++; 																		//  if the counter is 3 - the numbers on the vertical brick on the right are made the same
					due[i][j] = Integer.toString(Layer2[i][j] )+" -"; due[i-1][j] = Integer.toString(Layer2[i-1][j] )+" -"; break;			//  turning the numbers to strings in order to put lines in between 
					case 4: Layer2[i][j] = Layer2[i][j+1] = x; x++; 																		//	if the counter is 4 - the numbers on the bottom brick on the left are made the same
					due[i][j] = Integer.toString(Layer2[i][j])+""; due[i][j+1] = Integer.toString(Layer2[i][j+1] )+" -"; break;				//  turning the numbers to strings in order to put lines in between 
					case 5: Layer2[i-1][j] = Layer2[i-1][j-1] = x; x++; 																	//	if the counter is 5 - the numbers on the upper brick on the left are made the same
					due[i-1][j] = Integer.toString(Layer2[i-1][j])+" -"; due[i-1][j-1] = Integer.toString(Layer2[i-1][j-1])+""; break;		//  turning the numbers to strings in order to put lines in between 
					case 6: Layer2[i][j] = Layer2[i][j+1] = x; x++; 																		//	if the counter is 6 - the numbers on the bottom brick on the right are made the same
					due[i][j] = Integer.toString(Layer2[i][j])+""; due[i][j+1] = Integer.toString(Layer2[i][j+1])+" -"; break;				//  turning the numbers to strings in order to put lines in between 
					case 7: Layer2[i-1][j] = Layer2[i-1][j-1] = x; x++; 																	//	if the counter is 7 - the numbers on the upper brick on the right are made the same
					due[i-1][j] = Integer.toString(Layer2[i-1][j] )+" -"; due[i-1][j-1] = Integer.toString(Layer2[i-1][j-1] )+""; break;	//  turning the numbers to strings in order to put lines in between 
				}									
					 G++;				// the counter grows with every next brick
					 if(G>7) {G=0;}		// if the counter is above 7 we nullify it  						
				}						
			}			
		}
		for (int i=0; i<N; i++) {					// going through all the rows
				
			for (int j=0; j<M; j++) {				// going through all the bricks in a row
				System.out.print(due [i][j]+" ");	// laying out the bricks 			
			}
			System.out.println();					// going to the next row
		}
	}	

	
	
}
